//
//  DetailViewController.m
//  app-kanamobi
//
//  Created by Paula Hasstenteufel on 7/4/16.
//  Copyright © 2016 Paula Hasstenteufel. All rights reserved.
//

#import "DetailViewController.h"

@interface DetailViewController ()

@end

@implementation DetailViewController

@synthesize lblPostTitle, lblPostBody, lblPostId, currentPost;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setLabels];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

//gets post from cell so we can access all other parameters
- (void)getPost:(id)postObject {
    
    currentPost = postObject;
    
}

//sets labels according to parameters on postobj selected
- (void)setLabels {
    
    lblPostTitle.text = currentPost.postTitle;
    lblPostBody.text = currentPost.postBody;
    
    NSString* pi = currentPost.postId;
    lblPostId.text = [NSString stringWithFormat: @"Post ID: %@", pi];
}

@end
