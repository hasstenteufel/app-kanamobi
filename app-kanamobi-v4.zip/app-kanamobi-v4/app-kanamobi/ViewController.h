//
//  ViewController.h
//  app-kanamobi
//
//  Created by Paula Hasstenteufel on 7/1/16.
//  Copyright © 2016 Paula Hasstenteufel. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "User.h"

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *txt_username;
@property (weak, nonatomic) IBOutlet UITextField *txt_password;

@property (nonatomic, strong) NSMutableArray *jsonArray;
@property (nonatomic, strong) NSMutableArray *usersArray;

- (IBAction)btn_login:(UIButton *)sender;
- (IBAction)btn_signUp:(UIButton *)sender;


@end

