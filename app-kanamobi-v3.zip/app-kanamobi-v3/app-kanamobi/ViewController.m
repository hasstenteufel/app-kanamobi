//
//  ViewController.m
//  app-kanamobi
//
//  Created by Paula Hasstenteufel on 7/1/16.
//  Copyright © 2016 Paula Hasstenteufel. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btn_login:(UIButton *)sender {
    
    if ([self.txt_username.text isEqual: @"test"] && [self.txt_password.text isEqual: @"1234"]) {
        
        UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName: @"Main" bundle:nil];
        
        UIViewController *vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"ListViewController"];
        
        [self presentViewController:vc animated:NO completion:nil];
        
    } else {
        
        NSLog(@"Fail");
    }
    
}

- (IBAction)btn_signUp:(UIButton *)sender {
}


@end
