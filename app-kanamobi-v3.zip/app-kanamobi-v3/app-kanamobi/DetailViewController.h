//
//  DetailViewController.h
//  app-kanamobi
//
//  Created by Paula Hasstenteufel on 7/4/16.
//  Copyright © 2016 Paula Hasstenteufel. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Post.h"

@interface DetailViewController : UIViewController

@property (nonatomic, strong) IBOutlet UILabel *lblPostTitle;
@property (nonatomic, strong) IBOutlet UILabel *lblPostBody;
@property (nonatomic, strong) IBOutlet UILabel *lblPostId;

@property (nonatomic, strong) Post *currentPost;

- (void)getPost:(id)postObject;
- (void)setLabels;

@end
