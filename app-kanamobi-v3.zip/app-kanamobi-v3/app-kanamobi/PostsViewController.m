//
//  PostsViewController.m
//  app-kanamobi
//
//  Created by Paula Hasstenteufel on 7/4/16.
//  Copyright © 2016 Paula Hasstenteufel. All rights reserved.
//

#import "PostsViewController.h"
#import "Post.h"
#import "DetailViewController.h"

@interface PostsViewController ()

@end

@implementation PostsViewController

@synthesize jsonArray, postsArray;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"Leanne Graham's Posts";
    [self retrieveData];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return postsArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
    
    Post *postObject;
    postObject = [postsArray objectAtIndex:indexPath.row];
    
    cell.textLabel.text = postObject.postTitle;
    
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    return cell;
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    
    if ([[segue identifier] isEqualToString:@"showDetailView"]) {
        
        
        NSIndexPath *ip = [self.tableView indexPathForSelectedRow];
        
        Post *p = [postsArray objectAtIndex:ip.row];
        [[segue destinationViewController]getPost:p];
        
    }
}


- (void)retrieveData {
    
    NSError *error;
    NSString *url_string = [NSString stringWithFormat: @"http://jsonplaceholder.typicode.com/posts?userId=1"];
    NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:url_string]];
    
    jsonArray = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
    postsArray = [[NSMutableArray alloc] init];
    
    for (int i = 0; i < jsonArray.count; i++) {
        
        NSString *pUser = [[jsonArray objectAtIndex:i] objectForKey:@"userId"];
        NSString *pId = [[jsonArray objectAtIndex:i] objectForKey:@"id"];
        NSString *pTitle = [[jsonArray objectAtIndex:i] objectForKey:@"title"];
        NSString *pBody = [[jsonArray objectAtIndex:i] objectForKey:@"body"];
        
        [postsArray addObject: [[Post alloc]initWithPostUser:pUser andPostId:pId andPostTitle:pTitle andPostBody:pBody]];
        
    }
    
    [self.tableView reloadData];
    //NSLog(@" error => %@ ", [error localizedDescription]);
    
}

@end
