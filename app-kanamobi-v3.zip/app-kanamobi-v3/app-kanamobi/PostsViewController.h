//
//  PostsViewController.h
//  app-kanamobi
//
//  Created by Paula Hasstenteufel on 7/4/16.
//  Copyright © 2016 Paula Hasstenteufel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PostsViewController : UITableViewController

@property (nonatomic, strong) NSMutableArray *jsonArray;
@property (nonatomic, strong) NSMutableArray *postsArray;

- (void)retrieveData;

@end
