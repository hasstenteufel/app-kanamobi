//
//  Post.m
//  app-kanamobi
//
//  Created by Paula Hasstenteufel on 7/4/16.
//  Copyright © 2016 Paula Hasstenteufel. All rights reserved.
//

#import "Post.h"

@implementation Post

@synthesize postUser, postId, postTitle, postBody;

- (id)initWithPostUser: (NSString *)pUser andPostId: (NSString *)pId andPostTitle: (NSString *)pTitle andPostBody: (NSString *)pBody {
    
    self = [super init];
    if (self) {
        
        postUser = pUser;
        postId = pId;
        postTitle = pTitle;
        postBody = pBody;
        
    }
    
    return self;
    
}

@end
