//
//  RegisterViewController.m
//  app-kanamobi
//
//  Created by Paula Hasstenteufel on 7/6/16.
//  Copyright © 2016 Paula Hasstenteufel. All rights reserved.
//

#import "RegisterViewController.h"

@interface RegisterViewController ()

@end

@implementation RegisterViewController

@synthesize txtUsername, txtPassword;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)btnRegister:(id)sender {
    
    if (self.txtUsername.text.length > 0 && self.txtPassword.text.length > 0) {
        
        NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
        
        [d setObject:txtUsername.text forKey:@"username"];
        [d setObject:txtPassword.text forKey:@"password"];
        
        //UIAlertController *success = [UIAlertController alertControllerWithTitle:@"Success!" message:@"You have been registered successfully!" preferredStyle:UIAlertControllerStyleAlert];
        //UIAlertAction *ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        //[success addAction:ok];
        //[self presentViewController:success animated:YES completion:nil];
        
        UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName: @"Main" bundle:nil];
        UIViewController *vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"FirstViewController"];
        [self presentViewController:vc animated:NO completion:nil];
        
    } else {
        
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Blank Field" message:@"Please fill in all blanks" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction *ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:ok];
        
        [self presentViewController:alertController animated:YES completion:nil];
        
    }
    
    
    
}
@end
