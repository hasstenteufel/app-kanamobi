//
//  User.h
//  app-kanamobi
//
//  Created by Paula Hasstenteufel on 7/5/16.
//  Copyright © 2016 Paula Hasstenteufel. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface User : NSObject

@property (nonatomic, strong) NSString * username;
@property (nonatomic, strong) NSString * password;

- (id)initWithUsername:(NSString*)uName andPassword: (NSString*)pWord;

@end
