//
//  User.m
//  app-kanamobi
//
//  Created by Paula Hasstenteufel on 7/5/16.
//  Copyright © 2016 Paula Hasstenteufel. All rights reserved.
//

#import "User.h"

@implementation User

@synthesize username, password;

- (id)initWithUsername:(NSString*)uName andPassword: (NSString*)pWord {
    
    self = [super init];
    if (self) {
        
        username = uName;
        password = pWord;        
        
    }
    
    return self;
}

@end
