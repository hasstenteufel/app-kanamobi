//
//  RegisterViewController.h
//  app-kanamobi
//
//  Created by Paula Hasstenteufel on 7/6/16.
//  Copyright © 2016 Paula Hasstenteufel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RegisterViewController : UIViewController

@property (strong, nonatomic) IBOutlet UITextField *txtUsername;
@property (strong, nonatomic) IBOutlet UITextField *txtPassword;

- (IBAction)btnRegister:(id)sender;

@end
