//
//  ViewController.m
//  app-kanamobi
//
//  Created by Paula Hasstenteufel on 7/1/16.
//  Copyright © 2016 Paula Hasstenteufel. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize txt_password, txt_username, jsonArray, usersArray;

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
    
    
    // Dispose of any resources that can be recreated.
}

- (IBAction)btn_login:(UIButton *)sender {
    
    //flag to protect UIALert
    BOOL ac = FALSE;
    
    //makes sure there is any value inputed by user
    if (self.txt_username.text.length > 0 && self.txt_password.text.length > 0) {
        
        NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
        
        if ([txt_username.text isEqualToString:[d objectForKey:@"username"]] && [txt_password.text isEqualToString:[d objectForKey:@"password"]]) {
            
            UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName: @"Main" bundle:nil];
            UIViewController *vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"ListViewController"];
            
            [self presentViewController:vc animated:NO completion:nil];
            
            //NSLog(@"it works!");
            NSLog(@"%@", [[NSUserDefaults standardUserDefaults] dictionaryRepresentation]);
            
        } else {            
         
            //gets keys and values from json
            NSError *error;
            NSString *url_string = [NSString stringWithFormat: @"http://jsonplaceholder.typicode.com/users"];
            NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:url_string]];
            
            jsonArray = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
            usersArray = [[NSMutableArray alloc] init];
            
            //loops through JSON Array creating new USER Arrays and testing each one for username/pw hits
            for (int i = 0; i < jsonArray.count; i++) {
                
                NSString *uName = [[jsonArray objectAtIndex:i] objectForKey:@"username"];
                NSString *pWord = [[jsonArray objectAtIndex:i] objectForKey:@"email"];
                
                [usersArray addObject: [[User alloc]initWithUsername:uName andPassword:pWord]];
                
                if ([self.txt_username.text isEqual:uName] && [self.txt_password.text isEqual:pWord]) {
                    
                    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName: @"Main" bundle:nil];
                    UIViewController *vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"ListViewController"];
                    
                    [self presentViewController:vc animated:NO completion:nil];
                    
                    //NSLog(@"Logou: %@ com %@",uName, pWord);
                    
                } else {
                    
                    //NSLog(@"Wrong!");
                    
                    //if statement to protect UIAlert
                    if (!ac) {
                        
                        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Could not Log In" message:@"Login or Password incorrect" preferredStyle:UIAlertControllerStyleAlert];
                        
                        UIAlertAction *ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
                        [alertController addAction:ok];
                        
                        [self presentViewController:alertController animated:YES completion:nil];
                        
                        ac = TRUE;
                    }
                }    
            }
        }
        
        
    } else {
        
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Blank Field" message:@"Please fill in all blanks" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction *ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:ok];
        
        [self presentViewController:alertController animated:YES completion:nil];
        //NSLog(@"Fill in the blanks");
        
    }
}


- (IBAction)btn_signUp:(UIButton *)sender {}




@end
