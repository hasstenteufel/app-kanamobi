//
//  AppDelegate.h
//  app-kanamobi
//
//  Created by Paula Hasstenteufel on 7/1/16.
//  Copyright © 2016 Paula Hasstenteufel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

