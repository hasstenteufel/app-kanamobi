//
//  Post.h
//  app-kanamobi
//
//  Created by Paula Hasstenteufel on 7/4/16.
//  Copyright © 2016 Paula Hasstenteufel. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Post : NSObject

@property (nonatomic, strong) NSString * postUser;
@property (nonatomic, strong) NSString * postId;
@property (nonatomic, strong) NSString * postTitle;
@property (nonatomic, strong) NSString * postBody;

- (id)initWithPostUser: (NSString *)pUser andPostId: (NSString *)pId andPostTitle: (NSString *)pTitle andPostBody: (NSString *)pBody;

@end
