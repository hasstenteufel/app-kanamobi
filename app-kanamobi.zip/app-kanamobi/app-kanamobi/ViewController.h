//
//  ViewController.h
//  app-kanamobi
//
//  Created by Paula Hasstenteufel on 7/1/16.
//  Copyright © 2016 Paula Hasstenteufel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *txt_username;
@property (weak, nonatomic) IBOutlet UITextField *txt_password;

- (IBAction)btn_login:(UIButton *)sender;
- (IBAction)btn_signUp:(UIButton *)sender;

@end

